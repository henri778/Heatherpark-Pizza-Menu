Heather Park Superspar — Pizza Order app files

Included:
- pizza_order_app_final_mobile.html   (open or use as index.html)
- Spar logo SQUARE.jpg               (logo used by the page)

How to publish (Netlify Drop - recommended):
1. Go to https://app.netlify.com/drop
2. Drag & drop this ZIP file onto the page.
3. Netlify will publish immediately and give you a public URL.
4. Paste the URL here and I'll generate a QR and PWA assets for you.

Notes:
- If you rename the HTML to index.html it will act as the site root on static hosts.
- If you want me to add a manifest.json and icons in the ZIP (for installable PWA), tell me and I will add them.